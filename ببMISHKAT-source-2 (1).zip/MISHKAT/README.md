# مِشكاة | MISHKAT

**نورٌ لقلبك.. في كل حين**

مشروع Android بلغة Kotlin وJetpack Compose بواجهة RTL وهوية تفاحيّة. هذه الحزمة هي **نسخة تأسيسية/MVP صريحة الحدود** وليست تنفيذًا مكتملًا لكل المواصفات الكبيرة الواردة في الطلب. لن يتم تضمين نصوص قرآنية أو أذكار مولّدة/وهمية؛ الميزات التي تحتاج مصدرًا أو خطًا معتمدًا غير متوفر تُظهر حالة غير متاح بوضوح.

## الموجود في هذا التسليم

- مشروع Android/Gradle يستهدف `minSdk 24` و`compileSdk/targetSdk 37`.
- واجهة Compose/Material 3 RTL، لوحة رئيسية، شريط تنقل عائم، ألوان فاتح/داكن/حسب النظام محفوظة عبر DataStore، ومكوّن `AppText` موحّد.
- طبقات أولية: Room entities/DAO/database، repository، Hilt DI، Retrofit/OkHttp مع مهلات وذاكرة تخزين مؤقت وإعادة محاولة للاتصال، وWorkManager لمزامنة بيانات القرآن عند تهيئة الاعتماد.
- عميل موثّق لـ Quran Foundation Content API v4 يجلب فهرس السور والآيات، ويحفظها محليًا ويتحقق من 114 سورة و6236 آية قبل إعلان اكتمال المزامنة.
- شاشة حالة مصادر وسجل أخطاء، وتنزيلات مع حالة محلية، وفهرس سور من بيانات قاعدة البيانات، وعداد أذكار محلي يعمل فقط إن وُجدت بيانات مستوردة.
- خدمة Media3 `MediaSessionService` أساسية، شاشة بداية Android، وأيقونة adaptive وأيقونة monochrome وأصول شعار SVG مرسومة كـ paths مع PNG بالحجم 512×512.
- GitHub Actions لبناء `assembleDebug` وتعبئة APK حقيقي في Artifact عند رفع المشروع إلى GitHub.

## ما لم يكتمل بعد

لم يُنفذ بعد: تحميل كتاب حصن المسلم كاملًا من مصدر تمّت معاينة استجابته والتحقق من ترخيصه، خطوط Cairo/Noto Naskh وخطوط QCF الرسمية، تخطيط صفحات المصحف 604 صفحة وعارض الآيات، الترويسات المخطوطة الرسمية، التفسير ومعاني الكلمات والتجويد والتسميع، اختيار الموقع الفعلي وحساب الصلاة باستخدام Adhan، بوصلة القبلة، جدولة المنبهات، مصادر ملفات التلاوة والتحقق من القارئ، ربط الكبسولة الصوتية بالخدمة، الودجات، النسخ الاحتياطي، التعريف الأولي من ثلاث خطوات، واختبارات أجهزة فعلية. تفاصيل كل بند في [`TESTING.md`](TESTING.md).

لم يكن بالإمكان بناء APK من بيئة العمل الحالية: لا Android SDK ولا Gradle مثبتان، والاتصال الخارجي من حاوية البناء غير متاح. لذلك **لا يوجد APK مزعوم أو ملف placeholder** ضمن هذا الـZIP. اضبط GitHub Actions ليتولى البناء على خادم يملك SDK، ثم نزّل Artifact `mishkat-debug-apk`.

## فتح المشروع وبناؤه

1. افتح مجلد `MISHKAT` في Android Studio بإصدار يدعم Android Gradle Plugin 9.1.1 وAPI 37.
2. سجّل تطبيقًا في Quran Foundation Developer Console وأنشئ بيانات اعتماد Content API. لا تُضمّن مفاتيحك في مستودع عام.
3. مرّر `QURAN_CLIENT_ID` و`QURAN_AUTH_TOKEN` عبر `~/.gradle/gradle.properties` أو عبر `-PQURAN_CLIENT_ID=... -PQURAN_AUTH_TOKEN=...` عند البناء. وفي GitHub أضف Secrets بالاسمين نفسيهما؛ الـWorkflow يمررهما إلى Gradle عبر متغيرات `ORG_GRADLE_PROJECT_...`.
4. نفّذ `python3 scripts/verify_project.py` ثم `./gradlew assembleDebug` على جهاز/CI مُجهّز بـJDK 17 وAndroid SDK API 37.
5. بعد نجاح البناء، نفّذ `python3 scripts/package_apk.py app/build/outputs/apk/debug/app-debug.apk` لنسخ **APK مبني فعليًا** وإنشاء ZIP له. يرفض البرنامج إنشاء حزمة إذا لم يجد APK أو كان حجمه لا يتجاوز 1,000,000 بايت.

## مصادر البيانات

راجع [`SOURCES_AND_LICENSES.md`](SOURCES_AND_LICENSES.md). لم تُضمّن بيانات قرآن أو أذكار في الـassets. مصدر قرآن Foundation يتطلب تهيئة اعتماد API؛ ولا يُعرض نص الآيات في الواجهة حتى تُضمّن حزمة الخط المطابق لبيانات المصدر.

## هيكل مختصر

```text
app/src/main/java/com/mishkat/app/
  data/       Room, Retrofit, repository, DataStore
  di/         Hilt providers
  worker/     WorkManager content sync
  audio/      Media3 session service
  ui/         Material 3 theme and navigation
  ui/screens/ app screens and explicit unavailable states
scripts/      static verification, icon export and APK packaging
.github/      Actions debug build workflow
assets/brand/ path-only SVG brand files and 512×512 artwork
```
