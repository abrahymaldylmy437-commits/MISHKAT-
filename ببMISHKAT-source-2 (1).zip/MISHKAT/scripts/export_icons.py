#!/usr/bin/env python3
"""Export app/market PNGs from the path-only SVG brand assets.
Requires cairosvg and Pillow. The SVG paths are shipped; font files are not.
"""
from pathlib import Path
import cairosvg
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "assets" / "brand"
ICON_SVG = ASSETS / "mishkat-icon-paths.svg"
LOCKUP_SVG = ASSETS / "mishkat-lockup-paths.svg"
RES = ROOT / "app" / "src" / "main" / "res"

if not ICON_SVG.exists() or not LOCKUP_SVG.exists():
    raise SystemExit("Missing path-only SVG files. Recreate them from assets/brand sources first.")

# Play Store artwork: exactly 512x512.
cairosvg.svg2png(url=str(ICON_SVG), write_to=str(ASSETS / "mishkat-icon-512.png"), output_width=512, output_height=512)
cairosvg.svg2png(url=str(LOCKUP_SVG), write_to=str(RES / "drawable-nodpi" / "mishkat_lockup.png"), output_width=900, output_height=310)

icon = Image.open(ASSETS / "mishkat-icon-512.png").convert("RGBA")
original = icon.load()
foreground = Image.new("RGBA", icon.size, (0, 0, 0, 0))
fg = foreground.load()
monochrome = Image.new("RGBA", icon.size, (0, 0, 0, 0))
mono = monochrome.load()
for y in range(icon.height):
    for x in range(icon.width):
        r, g, b, a = original[x, y]
        if (r, g, b) != (8, 72, 74):
            fg[x, y] = (r, g, b, a)
        if r > 200 and g > 190 and b > 170:
            mono[x, y] = (0, 0, 0, a)
foreground.save(RES / "drawable-nodpi" / "ic_launcher_foreground.png")
monochrome.save(RES / "drawable-nodpi" / "ic_launcher_monochrome.png")

sizes = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}
for density, size in sizes.items():
    dest = RES / f"mipmap-{density}" / "ic_launcher.png"
    dest.parent.mkdir(parents=True, exist_ok=True)
    rendered = Image.open(ASSETS / "mishkat-icon-512.png").convert("RGBA").resize((size, size), Image.Resampling.LANCZOS)
    rendered.save(dest)

print("Exported 512x512 market art, legacy density icons, adaptive foreground, monochrome icon, and lockup PNG.")
