#!/usr/bin/env python3
"""Copy a real Gradle-built debug APK to both requested output folders and zip it."""
from pathlib import Path
import shutil
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
source = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "app/build/outputs/apk/debug/app-debug.apk"
if not source.is_absolute():
    source = ROOT / source
if not source.is_file():
    raise SystemExit(f"APK not found: {source}. This script refuses to fabricate a placeholder APK.")
size = source.stat().st_size
if size <= 1_000_000:
    raise SystemExit(f"APK is only {size} bytes; the requested minimum is greater than 1 MB. No APK was packaged.")

build_dir = ROOT / ".build-outputs"
download_dir = ROOT / "APK_DOWNLOAD"
build_dir.mkdir(exist_ok=True)
download_dir.mkdir(exist_ok=True)
shutil.copy2(source, build_dir / "app-debug.apk")
shutil.copy2(source, download_dir / "app-debug.apk")
zip_paths = [build_dir / "mishkat-debug-apk.zip", download_dir / "mishkat-debug-apk.zip"]
for zip_path in zip_paths:
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        archive.write(source, arcname="app-debug.apk")
print(f"Copied real APK ({size} bytes) to .build-outputs/app-debug.apk and APK_DOWNLOAD/app-debug.apk")
print("Created .build-outputs/mishkat-debug-apk.zip and APK_DOWNLOAD/mishkat-debug-apk.zip")
