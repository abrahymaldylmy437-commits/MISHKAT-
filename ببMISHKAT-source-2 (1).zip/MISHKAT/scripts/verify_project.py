#!/usr/bin/env python3
"""Static project checks that do not require Android SDK or external network access."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
errors = []
passed = []

def check(name, condition, detail=""):
    if condition:
        passed.append(name)
        print(f"PASS | {name}" + (f" — {detail}" if detail else ""))
    else:
        errors.append(name)
        print(f"FAIL | {name}" + (f" — {detail}" if detail else ""))

kt_root = ROOT / "app/src/main/java"
kt_files = list(kt_root.rglob("*.kt"))
text_outside_wrapper = []
for path in kt_files:
    if path.name == "AppText.kt":
        continue
    body = path.read_text(encoding="utf-8")
    if re.search(r"(?<![A-Za-z])Text\s*\(", body):
        text_outside_wrapper.append(str(path.relative_to(ROOT)))
check("Compose Text is wrapped by AppText", not text_outside_wrapper, ", ".join(text_outside_wrapper))

theme_file = ROOT / "app/src/main/java/com/mishkat/app/ui/Theme.kt"
theme = theme_file.read_text(encoding="utf-8")
forbidden = ["#3DDC97", "#DDF5E3", "#00C9A7", "#A8EED5", "#E0FFF5"]
check("No banned mint/teal colors in UI theme", not any(c.lower() in theme.lower() for c in forbidden))
check("Required light apple palette declared", all(c.lower().replace("#", "") in theme.lower().replace("#", "") for c in ["#2F5E1A", "#4F8A24", "#7DB82E", "#F6F8F0", "#FBFCF7", "#E2E9D2", "#1F2A17", "#5B6650", "#B8942F"]))
check("Required dark palette declared", all(c.lower().replace("#", "") in theme.lower().replace("#", "") for c in ["#12170E", "#1B2215"]))

manifest = (ROOT / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
check("minSdk 24 declared", bool(re.search(r"minSdk\s*=\s*24", gradle)))
check("target/compile SDK 37 declared", "targetSdk = 37" in gradle and "compileSdk = 37" in gradle)
check("RTL application support declared", 'android:supportsRtl="true"' in manifest)
check("Room / DataStore / Hilt / WorkManager / Media3 dependencies declared", all(x in gradle for x in ["libs.androidx.room.runtime", "libs.androidx.datastore", "libs.hilt.android", "libs.androidx.work.runtime", "libs.androidx.media3.session"]))
check("Quran Foundation documented endpoint is used", 'https://apis.quran.foundation/content/api/v4/' in (ROOT / "app/src/main/java/com/mishkat/app/data/QuranApi.kt").read_text(encoding="utf-8"))
check("Quran text not bundled as hand-written sample content", not any(p.suffix.lower() == ".json" and "quran" in p.name.lower() for p in (ROOT / "app/src/main/assets").rglob("*") if p.is_file()) if (ROOT / "app/src/main/assets").exists() else True)

for svg_name in ["mishkat-icon-paths.svg", "mishkat-lockup-paths.svg"]:
    svg_path = ROOT / "assets/brand" / svg_name
    svg = svg_path.read_text(encoding="utf-8") if svg_path.exists() else ""
    check(f"{svg_name} uses vector paths, not live text", "<path" in svg and not re.search(r"<text(?:\s|>)", svg))

check("Path-based icon export exists", (ROOT / "app/src/main/res/drawable-nodpi/ic_launcher_foreground.png").exists())
check("Adaptive icon resources exist", (ROOT / "app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml").exists() and (ROOT / "app/src/main/res/mipmap-anydpi-v33/ic_launcher.xml").exists())
check("No hardcoded Quran verse text bundled in source", not any(re.search(r"إِنَّ|الْحَمْدُ لِلَّهِ|قُلْ هُوَ اللَّهُ", p.read_text(encoding="utf-8")) for p in kt_files))
check("Testing report exists", (ROOT / "TESTING.md").exists())

print(f"\nSummary: {len(passed)} passed, {len(errors)} failed.")
sys.exit(1 if errors else 0)
