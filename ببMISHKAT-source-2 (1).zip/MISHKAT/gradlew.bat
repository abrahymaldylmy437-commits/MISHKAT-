@echo off
setlocal
where gradle >NUL 2>NUL
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo Gradle 9.3.1 is not installed. Run gradlew from a machine with curl/wget available on a POSIX shell, or install Gradle 9.3.1 and retry.
exit /b 127
