package com.mishkat.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccessTime
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.SelfImprovement
import androidx.compose.material.icons.outlined.Spa
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material.icons.outlined.NightlightRound
import androidx.compose.material.icons.outlined.Savings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mishkat.app.MishkatViewModel
import com.mishkat.app.data.ThemeChoice
import com.mishkat.app.ui.components.AppText
import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun HomeScreen(viewModel: MishkatViewModel, onNavigate: (String) -> Unit) {
    val lastReadPage by viewModel.lastReadPage.collectAsState()
    val readPageCount by viewModel.readPageCount.collectAsState()
    val surahs by viewModel.surahs.collectAsState()
    val verseCount by viewModel.verseCount.collectAsState()
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            TopHeader(
                onSearch = { onNavigate("search") },
                onFavorite = { onNavigate("settings") },
                onLocation = { onNavigate("location") }
            )
        }
        item { NextPrayerCard(onClick = { onNavigate("location") }) }
        item { PrayerGrid(onClick = { onNavigate("prayers") }) }
        item { DailyTools(onNavigate = onNavigate) }
        item {
            SectionHeading(title = "متابعة القراءة", action = "فتح الفهرس", onAction = { onNavigate("quran") })
            Spacer(Modifier.height(8.dp))
            if (lastReadPage != null) {
                SurfaceCard(onClick = { onNavigate("quran") }) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                            Icon(Icons.Outlined.MenuBook, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        }
                        Column(Modifier.weight(1f)) {
                            AppText("آخر صفحة قُرئت", style = MaterialTheme.typography.titleMedium)
                            AppText("صفحة ${lastReadPage!!.pageNumber} • حفظ من سجل القراءة المحلي", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        AppText("متابعة", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
                    }
                }
            } else {
                SurfaceCard(onClick = { onNavigate("quran") }) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        AppText("ابدأ من فهرس المصحف", style = MaterialTheme.typography.titleMedium)
                        AppText(
                            if (surahs.isEmpty()) "نزّل الفهرس من المصدر الموثوق أولًا. لن نعرض أسماء أو أعدادًا تخمينية." else "لم تُسجّل صفحة قراءة بعد.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
        item {
            SectionHeading(title = "حصيلتك", action = null, onAction = {})
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard(Modifier.weight(1f), "صفحات مقروءة", if (readPageCount > 0) readPageCount.toString() else "—", Icons.Outlined.MenuBook)
                MetricCard(Modifier.weight(1f), "سور محفوظة محليًا", if (surahs.isNotEmpty()) surahs.size.toString() else "—", Icons.Outlined.BookmarkBorder)
                MetricCard(Modifier.weight(1f), "آيات مخزنة", if (verseCount > 0) verseCount.toString() else "—", Icons.Outlined.Spa)
            }
            Spacer(Modifier.height(5.dp))
            AppText("الأرقام من قاعدة البيانات المحلية فقط؛ الشرطة تعني أن المصدر لم يُنزّل بعد.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            SurfaceCard(onClick = { onNavigate("downloads") }) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(Icons.Outlined.SelfImprovement, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(28.dp))
                    Column(Modifier.weight(1f)) {
                        AppText("آية اليوم", style = MaterialTheme.typography.titleMedium)
                        AppText("ستظهر من بيانات المصدر بعد تنزيل نص المصحف وخط العرض الرسمي.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(4.dp)) }
    }
}

@Composable
private fun TopHeader(onSearch: () -> Unit, onFavorite: () -> Unit, onLocation: () -> Unit) {
    val locale = remember { Locale("ar") }
    val date = remember { LocalDate.now() }
    val gregorian = remember(date) { runCatching { DateTimeFormatter.ofPattern("EEEE، d MMMM yyyy", locale).format(date) }.getOrDefault(date.toString()) }
    val hijri = remember(date) {
        runCatching { DateTimeFormatter.ofPattern("d MMMM yyyy هـ", locale).format(HijrahDate.from(date)) }.getOrDefault("التاريخ الهجري")
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            AppText("مِشكاة", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
            AppText("$hijri  •  $gregorian", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
        }
        RoundAction(Icons.Outlined.Search, "بحث", onSearch)
        Spacer(Modifier.width(7.dp))
        RoundAction(Icons.Outlined.FavoriteBorder, "المفضلة", onFavorite)
        Spacer(Modifier.width(7.dp))
        Row(
            modifier = Modifier.clip(CircleShape).background(MaterialTheme.colorScheme.surface).border(1.dp, MaterialTheme.colorScheme.outline, CircleShape).clickable(onClick = onLocation).padding(horizontal = 10.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Outlined.Explore, contentDescription = null, modifier = Modifier.size(17.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(4.dp))
            AppText("موقعك", style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
private fun RoundAction(icon: ImageVector, label: String, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.size(42.dp),
        shape = CircleShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.8f))
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Icon(icon, contentDescription = label, tint = MaterialTheme.colorScheme.onSurface) }
    }
}

@Composable
private fun NextPrayerCard(onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(164.dp),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF2F5E1A), Color(0xFF4F8A24), Color(0xFF6E982A))))) {
            Canvas(Modifier.fillMaxSize()) {
                val archColor = Color.White.copy(alpha = 0.12f)
                val w = size.width
                val h = size.height
                for (i in 0..3) {
                    val inset = i * 17f
                    val path = Path().apply {
                        moveTo(w * 0.50f, h * 0.14f + inset)
                        cubicTo(w * 0.25f, h * 0.14f + inset, w * 0.24f, h * 0.95f, w * 0.50f, h * 0.95f)
                        cubicTo(w * 0.76f, h * 0.95f, w * 0.75f, h * 0.14f + inset, w * 0.50f, h * 0.14f + inset)
                    }
                    drawPath(path, archColor, style = Stroke(width = 1.2f, cap = StrokeCap.Round))
                }
            }
            Row(Modifier.fillMaxSize().padding(20.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    AppText("الصلاة القادمة", style = MaterialTheme.typography.labelLarge, color = Color(0xFFEAF2DF))
                    AppText("حدّد موقعك أولًا", style = MaterialTheme.typography.headlineMedium, color = Color(0xFFF8F6E9))
                    AppText("لحساب الوقت بدقة حسب طريقة الحساب التي تختارها", style = MaterialTheme.typography.bodySmall, color = Color(0xFFEAF2DF))
                }
                Box(Modifier.size(88.dp), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize()) {
                        drawCircle(Color.White.copy(alpha = 0.30f), style = Stroke(width = 5.dp.toPx()))
                    }
                    Icon(Icons.Outlined.AccessTime, contentDescription = null, tint = Color.White, modifier = Modifier.size(34.dp))
                }
            }
        }
    }
}

private data class PrayerTileData(val name: String, val icon: ImageVector)

@Composable
private fun PrayerGrid(onClick: () -> Unit) {
    val prayers = listOf(
        PrayerTileData("الفجر", Icons.Outlined.WbSunny),
        PrayerTileData("الشروق", Icons.Outlined.WbSunny),
        PrayerTileData("الظهر", Icons.Outlined.WbSunny),
        PrayerTileData("العصر", Icons.Outlined.WbSunny),
        PrayerTileData("المغرب", Icons.Outlined.NightlightRound),
        PrayerTileData("العشاء", Icons.Outlined.NightlightRound),
        PrayerTileData("منتصف الليل", Icons.Outlined.NightlightRound)
    )
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            prayers.take(4).forEach { PrayerTile(it, onClick, Modifier.weight(1f)) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            prayers.drop(4).forEach { PrayerTile(it, onClick, Modifier.weight(1f)) }
            Spacer(Modifier.weight(1f))
        }
        AppText("الأوقات والتنبيهات لا تُعرض قبل حسابها من الموقع والإعدادات المختارة.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun PrayerTile(prayer: PrayerTileData, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Card(
        onClick = onClick,
        modifier = modifier.height(92.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.65f))
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 5.dp, vertical = 9.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(prayer.icon, contentDescription = null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(5.dp))
            AppText(prayer.name, style = MaterialTheme.typography.labelMedium, textAlign = TextAlign.Center, maxLines = 1)
            AppText("—:—", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun DailyTools(onNavigate: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            AppText("أدواتك اليومية", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            Card(onClick = { onNavigate("settings") }, shape = CircleShape, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Icon(Icons.Outlined.Tune, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
                    AppText("تخصيص", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            ToolItem("المصحف", Icons.Outlined.MenuBook) { onNavigate("quran") }
            ToolItem("الأذكار", Icons.Outlined.Spa) { onNavigate("azkar") }
            ToolItem("المسبحة", Icons.Outlined.Savings) { onNavigate("tasbeeh") }
            ToolItem("القبلة", Icons.Outlined.Explore) { onNavigate("qibla") }
            ToolItem("المواقيت", Icons.Outlined.AccessTime) { onNavigate("prayers") }
            ToolItem("التنزيلات", Icons.Outlined.BookmarkBorder) { onNavigate("downloads") }
        }
    }
}

@Composable
private fun ToolItem(label: String, icon: ImageVector, onClick: () -> Unit) {
    Column(Modifier.width(70.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Card(onClick = onClick, modifier = Modifier.size(58.dp), shape = CircleShape, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Icon(icon, contentDescription = label, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp)) }
        }
        AppText(label, style = MaterialTheme.typography.labelMedium, textAlign = TextAlign.Center, maxLines = 1)
    }
}

@Composable
private fun SectionHeading(title: String, action: String?, onAction: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        AppText(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
        if (action != null) Card(onClick = onAction, shape = CircleShape, colors = CardDefaults.cardColors(containerColor = Color.Transparent)) {
            AppText(action, modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
private fun SurfaceCard(onClick: () -> Unit, content: @Composable () -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.65f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        content = { content() }
    )
}

@Composable
private fun MetricCard(modifier: Modifier, title: String, value: String, icon: ImageVector) {
    Card(modifier = modifier, shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.65f))) {
        Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.Start, verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(19.dp))
            AppText(value, style = MaterialTheme.typography.headlineMedium)
            AppText(title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
        }
    }
}
