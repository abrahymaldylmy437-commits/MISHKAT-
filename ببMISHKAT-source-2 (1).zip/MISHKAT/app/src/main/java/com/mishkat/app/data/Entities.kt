package com.mishkat.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "surahs")
data class SurahEntity(
    @PrimaryKey val id: Int,
    val arabicName: String,
    val revelationPlace: String,
    val versesCount: Int,
    val startPage: Int?,
    val sourceUpdatedAt: Long
)

@Entity(tableName = "verses", indices = [Index("chapterId"), Index("pageNumber")])
data class VerseEntity(
    @PrimaryKey val verseKey: String,
    val chapterId: Int,
    val verseNumber: Int,
    val uthmaniText: String,
    val pageNumber: Int,
    val juzNumber: Int,
    val source: String,
    val sourceUpdatedAt: Long
)

@Entity(tableName = "read_pages")
data class ReadPageEntity(
    @PrimaryKey val pageNumber: Int,
    val firstReadAt: Long,
    val lastReadAt: Long
)

@Entity(tableName = "azkar_chapters", indices = [Index("sortOrder")])
data class AzkarChapterEntity(
    @PrimaryKey val id: String,
    val title: String,
    val sortOrder: Int,
    val category: String,
    val source: String,
    val downloadedAt: Long
)

@Entity(tableName = "azkar_items", indices = [Index("chapterId")])
data class AzkarItemEntity(
    @PrimaryKey val id: String,
    val chapterId: String,
    val text: String,
    val repeatCount: Int,
    val virtue: String?,
    val reference: String?,
    val audioUrl: String?,
    val source: String,
    val sourceUpdatedAt: Long
)

@Entity(tableName = "azkar_progress", indices = [Index("dayKey"), Index("chapterId")])
data class AzkarProgressEntity(
    @PrimaryKey val itemId: String,
    val chapterId: String,
    val dayKey: String,
    val remaining: Int,
    val updatedAt: Long
)

@Entity(tableName = "azkar_completions")
data class AzkarCompletionEntity(
    @PrimaryKey val completionKey: String,
    val chapterId: String,
    val dayKey: String,
    val completedAt: Long
)

@Entity(tableName = "source_status")
data class SourceStatusEntity(
    @PrimaryKey val sourceId: String,
    val isOnline: Boolean,
    val lastUpdatedAt: Long?,
    val lastError: String?,
    val errorLog: String
)
