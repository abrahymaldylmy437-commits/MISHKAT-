package com.mishkat.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        SurahEntity::class,
        VerseEntity::class,
        ReadPageEntity::class,
        AzkarChapterEntity::class,
        AzkarItemEntity::class,
        AzkarProgressEntity::class,
        AzkarCompletionEntity::class,
        SourceStatusEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class MishkatDatabase : RoomDatabase() {
    abstract fun dao(): MishkatDao

    companion object {
        @Volatile private var INSTANCE: MishkatDatabase? = null
        fun getInstance(context: Context): MishkatDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                MishkatDatabase::class.java,
                "mishkat.db"
            ).build().also { INSTANCE = it }
        }
    }
}
