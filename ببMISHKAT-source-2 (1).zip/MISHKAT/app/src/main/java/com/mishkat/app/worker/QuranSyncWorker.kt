package com.mishkat.app.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.mishkat.app.data.MishkatDatabase
import com.mishkat.app.data.MishkatRepository
import com.mishkat.app.data.QuranApiFactory

class QuranSyncWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        setProgress(workDataOf("message" to "بدء مزامنة المحتوى من المصدر"))
        val dao = MishkatDatabase.getInstance(applicationContext).dao()
        val repository = MishkatRepository(dao, QuranApiFactory.create(applicationContext), applicationContext)
        val result = repository.syncQuranIndexAndText { message ->
            setProgress(workDataOf("message" to message))
        }
        return result.fold(
            onSuccess = { Result.success(workDataOf("message" to "اكتملت مزامنة القرآن بعد التحقق من العدد المحلي")) },
            onFailure = { failure ->
                val message = failure.message ?: failure.javaClass.simpleName
                if (message.contains("غير مهيأة")) Result.failure(workDataOf("reason" to message))
                else if (runAttemptCount < 4) Result.retry()
                else Result.failure(workDataOf("reason" to message))
            }
        )
    }
}
