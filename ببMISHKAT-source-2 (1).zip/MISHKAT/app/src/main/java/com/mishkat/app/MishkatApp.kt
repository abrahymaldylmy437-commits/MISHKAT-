package com.mishkat.app

import android.app.Application
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.mishkat.app.data.MishkatDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import com.mishkat.app.worker.QuranSyncWorker
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MishkatApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Request first-run sync only when the local index is empty and credentials exist.
        // Without credentials, the UI exposes the real configuration error when the user tests the source.
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            val indexEmpty = MishkatDatabase.getInstance(this@MishkatApp).dao().getSurahs().isEmpty()
            if (indexEmpty && BuildConfig.QURAN_CLIENT_ID.isNotBlank() && BuildConfig.QURAN_AUTH_TOKEN.isNotBlank()) {
                val request = OneTimeWorkRequestBuilder<QuranSyncWorker>()
                    .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                    .build()
                WorkManager.getInstance(this@MishkatApp).enqueueUniqueWork("initial-quran-sync", ExistingWorkPolicy.KEEP, request)
            }
        }
    }
}
