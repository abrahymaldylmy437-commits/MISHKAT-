package com.mishkat.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MishkatDao {
    @Query("SELECT * FROM surahs ORDER BY id")
    fun observeSurahs(): Flow<List<SurahEntity>>

    @Query("SELECT * FROM surahs ORDER BY id")
    suspend fun getSurahs(): List<SurahEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putSurahs(items: List<SurahEntity>)

    @Query("SELECT * FROM verses ORDER BY chapterId, verseNumber")
    suspend fun getAllVerses(): List<VerseEntity>

    @Query("SELECT * FROM verses WHERE chapterId = :chapterId ORDER BY verseNumber")
    suspend fun getVersesForChapter(chapterId: Int): List<VerseEntity>

    @Query("SELECT * FROM verses WHERE pageNumber = :pageNumber ORDER BY chapterId, verseNumber")
    suspend fun getVersesForPage(pageNumber: Int): List<VerseEntity>

    @Query("SELECT COUNT(*) FROM verses")
    fun observeVerseCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putVerses(items: List<VerseEntity>)

    @Query("SELECT * FROM read_pages ORDER BY lastReadAt DESC LIMIT 1")
    fun observeLastReadPage(): Flow<ReadPageEntity?>

    @Query("SELECT COUNT(*) FROM read_pages")
    fun observeReadPageCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun markPageRead(page: ReadPageEntity)

    @Query("SELECT * FROM azkar_chapters ORDER BY sortOrder")
    fun observeAzkarChapters(): Flow<List<AzkarChapterEntity>>

    @Query("SELECT * FROM azkar_chapters ORDER BY sortOrder")
    suspend fun getAzkarChapters(): List<AzkarChapterEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putAzkarChapters(chapters: List<AzkarChapterEntity>)

    @Query("SELECT * FROM azkar_items WHERE chapterId = :chapterId ORDER BY id")
    fun observeAzkarItems(chapterId: String): Flow<List<AzkarItemEntity>>

    @Query("SELECT COUNT(*) FROM azkar_items WHERE chapterId = :chapterId")
    fun observeAzkarCountByChapter(chapterId: String): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putAzkarItems(items: List<AzkarItemEntity>)

    @Query("SELECT * FROM azkar_progress WHERE itemId = :itemId AND dayKey = :dayKey LIMIT 1")
    suspend fun getAzkarProgress(itemId: String, dayKey: String): AzkarProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putAzkarProgress(progress: AzkarProgressEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putCompletion(completion: AzkarCompletionEntity)

    @Query("SELECT EXISTS(SELECT 1 FROM azkar_completions WHERE chapterId = :chapterId AND dayKey = :dayKey)")
    suspend fun isChapterCompletedToday(chapterId: String, dayKey: String): Boolean

    @Query("SELECT * FROM source_status ORDER BY sourceId")
    fun observeSourceStatuses(): Flow<List<SourceStatusEntity>>

    @Query("SELECT * FROM source_status WHERE sourceId = :sourceId LIMIT 1")
    suspend fun getSourceStatus(sourceId: String): SourceStatusEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putSourceStatus(status: SourceStatusEntity)

    @Query("SELECT COUNT(*) FROM azkar_items")
    fun observeAzkarItemCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM azkar_chapters")
    fun observeAzkarChapterCount(): Flow<Int>
}
