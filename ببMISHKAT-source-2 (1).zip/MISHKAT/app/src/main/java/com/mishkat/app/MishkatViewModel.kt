package com.mishkat.app

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.mishkat.app.data.MishkatRepository
import com.mishkat.app.data.AzkarItemEntity
import java.time.LocalDate
import com.mishkat.app.data.SettingsStore
import com.mishkat.app.data.ThemeChoice
import com.mishkat.app.worker.QuranSyncWorker
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

@HiltViewModel
class MishkatViewModel @Inject constructor(
    private val repository: MishkatRepository,
    private val settings: SettingsStore,
    @ApplicationContext private val context: Context
) : ViewModel() {
    val surahs = repository.observeSurahs().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val verseCount = repository.observeVerseCount().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)
    val lastReadPage = repository.observeLastReadPage().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    val readPageCount = repository.observeReadPageCount().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)
    val azkarChapters = repository.observeAzkarChapters().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val azkarItemCount = repository.observeAzkarItemCount().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)
    val azkarChapterCount = repository.observeAzkarChapterCount().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)
    val sourceStatuses = repository.observeSources().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val theme = settings.theme.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ThemeChoice.LIGHT)

    private val _message = MutableStateFlow("")
    val message: StateFlow<String> = _message
    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy

    fun syncQuran() {
        viewModelScope.launch {
            _busy.value = true
            _message.value = "جاري جدولة تنزيل بيانات القرآن من المصدر المعتمد…"
            val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
            val request = OneTimeWorkRequestBuilder<QuranSyncWorker>().setConstraints(constraints).build()
            WorkManager.getInstance(context).enqueueUniqueWork("manual-quran-sync", ExistingWorkPolicy.REPLACE, request)
            WorkManager.getInstance(context).getWorkInfoByIdFlow(request.id).collect { info ->
                when (info?.state) {
                    WorkInfo.State.SUCCEEDED -> { _message.value = info.outputData.getString("message") ?: "اكتملت المزامنة"; _busy.value = false }
                    WorkInfo.State.FAILED -> { _message.value = info.outputData.getString("reason") ?: "فشلت المزامنة؛ راجع حالة المصادر"; _busy.value = false }
                    WorkInfo.State.CANCELLED -> { _message.value = "أُلغيت المزامنة"; _busy.value = false }
                    WorkInfo.State.RUNNING -> { _message.value = info.progress.getString("message") ?: "جاري تنزيل البيانات"; _busy.value = true }
                    else -> Unit
                }
            }
        }
    }

    fun testQuranSource() {
        viewModelScope.launch {
            _busy.value = true
            _message.value = "جاري اختبار مصدر القرآن…"
            repository.testQuranSource().fold(
                onSuccess = { _message.value = it },
                onFailure = { _message.value = it.message ?: "تعذر اختبار المصدر" }
            )
            _busy.value = false
        }
    }

    fun setTheme(choice: ThemeChoice) { viewModelScope.launch { settings.setTheme(choice) } }

    fun markPageRead(page: Int) {
        viewModelScope.launch { repository.markPageRead(page) }
    }

    fun observeAzkarItems(chapterId: String) = repository.observeAzkarItems(chapterId)
    fun observeAzkarCount(chapterId: String) = repository.observeAzkarCount(chapterId)
    suspend fun azkarRemaining(item: AzkarItemEntity): Int = repository.azkarRemaining(item, LocalDate.now().toString())
    fun saveAzkarRemaining(item: AzkarItemEntity, remaining: Int) {
        viewModelScope.launch { repository.saveAzkarRemaining(item, LocalDate.now().toString(), remaining) }
    }
    fun markAzkarChapterCompleted(chapterId: String) {
        viewModelScope.launch { repository.markAzkarChapterCompleted(chapterId, LocalDate.now().toString()) }
    }

    fun postMessage(message: String) { _message.value = message }
}
