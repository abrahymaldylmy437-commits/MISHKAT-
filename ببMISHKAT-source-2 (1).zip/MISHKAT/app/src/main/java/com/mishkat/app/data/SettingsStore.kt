package com.mishkat.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.mishkatDataStore by preferencesDataStore(name = "mishkat_preferences")

enum class ThemeChoice { LIGHT, DARK, SYSTEM }

@Singleton
class SettingsStore @Inject constructor(@ApplicationContext private val context: Context) {
    private val themeKey = stringPreferencesKey("theme_choice")
    val theme: Flow<ThemeChoice> = context.mishkatDataStore.data.map { prefs ->
        runCatching { ThemeChoice.valueOf(prefs[themeKey] ?: ThemeChoice.LIGHT.name) }.getOrDefault(ThemeChoice.LIGHT)
    }

    suspend fun setTheme(choice: ThemeChoice) {
        context.mishkatDataStore.edit { it[themeKey] = choice.name }
    }
}
