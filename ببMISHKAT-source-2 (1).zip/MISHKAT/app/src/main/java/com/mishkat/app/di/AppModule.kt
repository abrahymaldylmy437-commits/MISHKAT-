package com.mishkat.app.di

import android.content.Context
import com.mishkat.app.data.MishkatDao
import com.mishkat.app.data.MishkatDatabase
import com.mishkat.app.data.QuranApi
import com.mishkat.app.data.QuranApiFactory
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides @Singleton
    fun provideDatabase(@ApplicationContext context: Context): MishkatDatabase = MishkatDatabase.getInstance(context)

    @Provides
    fun provideDao(database: MishkatDatabase): MishkatDao = database.dao()

    @Provides @Singleton
    fun provideQuranApi(@ApplicationContext context: Context): QuranApi = QuranApiFactory.create(context)
}
