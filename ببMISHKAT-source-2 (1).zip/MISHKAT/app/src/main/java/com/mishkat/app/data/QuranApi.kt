package com.mishkat.app.data

import com.mishkat.app.BuildConfig
import com.google.gson.annotations.SerializedName
import okhttp3.Cache
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import java.io.File
import java.util.concurrent.TimeUnit

interface QuranApi {
    @GET("chapters")
    suspend fun chapters(@Query("language") language: String = "ar"): ChaptersResponse

    @GET("verses/by_chapter/{chapterNumber}")
    suspend fun versesByChapter(
        @Path("chapterNumber") chapterNumber: Int,
        @Query("fields") fields: String = "text_uthmani,page_number,juz_number",
        @Query("per_page") perPage: Int = 300,
        @Query("page") page: Int = 1
    ): VersesResponse
}

data class ChaptersResponse(@SerializedName("chapters") val chapters: List<ChapterDto>?)
data class ChapterDto(
    @SerializedName("id") val id: Int,
    @SerializedName("name_arabic") val nameArabic: String?,
    @SerializedName("revelation_place") val revelationPlace: String?,
    @SerializedName("verses_count") val versesCount: Int,
    @SerializedName("pages") val pages: List<Int>?
)
data class VersesResponse(
    @SerializedName("verses") val verses: List<VerseDto>?,
    @SerializedName("pagination") val pagination: PaginationDto?
)
data class PaginationDto(
    @SerializedName("current_page") val currentPage: Int?,
    @SerializedName("total_pages") val totalPages: Int?
)
data class VerseDto(
    @SerializedName("verse_key") val verseKey: String,
    @SerializedName("text_uthmani") val textUthmani: String?,
    @SerializedName("page_number") val pageNumber: Int?,
    @SerializedName("juz_number") val juzNumber: Int?,
    @SerializedName("verse_number") val verseNumber: Int?
)

object QuranApiFactory {
    fun create(context: android.content.Context): QuranApi {
        val logger = HttpLoggingInterceptor().apply {
            level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BASIC else HttpLoggingInterceptor.Level.NONE
        }
        val cache = Cache(File(context.cacheDir, "quran-http-cache"), 20L * 1024L * 1024L)
        val client = OkHttpClient.Builder()
            .cache(cache)
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(35, TimeUnit.SECONDS)
            .callTimeout(45, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .addInterceptor { chain ->
                val request = chain.request().newBuilder()
                    .header("Accept", "application/json")
                    .apply {
                        if (BuildConfig.QURAN_CLIENT_ID.isNotBlank()) header("x-client-id", BuildConfig.QURAN_CLIENT_ID)
                        if (BuildConfig.QURAN_AUTH_TOKEN.isNotBlank()) header("x-auth-token", BuildConfig.QURAN_AUTH_TOKEN)
                    }
                    .build()
                chain.proceed(request)
            }
            .addNetworkInterceptor { chain ->
                chain.proceed(chain.request()).newBuilder()
                    .header("Cache-Control", "public, max-age=300")
                    .build()
            }
            .addInterceptor(logger)
            .build()
        return Retrofit.Builder()
            .baseUrl("https://apis.quran.foundation/content/api/v4/")
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(QuranApi::class.java)
    }
}
