package com.mishkat.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.mishkat.app.data.ThemeChoice

private val AppleDark = Color(0xFF2F5E1A)
private val AppleMid = Color(0xFF4F8A24)
private val AppleLight = Color(0xFF7DB82E)
private val LightBackground = Color(0xFFF6F8F0)
private val LightSurface = Color(0xFFFBFCF7)
private val LightBorder = Color(0xFFE2E9D2)
private val MainText = Color(0xFF1F2A17)
private val SecondaryText = Color(0xFF5B6650)
private val CalmGold = Color(0xFFB8942F)
private val DarkBackground = Color(0xFF12170E)
private val DarkSurface = Color(0xFF1B2215)

private val MishkatLightScheme = lightColorScheme(
    primary = AppleMid,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE8F2D2),
    onPrimaryContainer = AppleDark,
    secondary = CalmGold,
    onSecondary = MainText,
    background = LightBackground,
    onBackground = MainText,
    surface = LightSurface,
    onSurface = MainText,
    surfaceVariant = Color(0xFFE8F2D2),
    onSurfaceVariant = SecondaryText,
    outline = LightBorder
)

private val MishkatDarkScheme = darkColorScheme(
    primary = AppleLight,
    onPrimary = Color(0xFF11180C),
    primaryContainer = Color(0xFF2F451E),
    onPrimaryContainer = Color(0xFFD8EAC0),
    secondary = Color(0xFFD4B75C),
    background = DarkBackground,
    onBackground = Color(0xFFE4EBD9),
    surface = DarkSurface,
    onSurface = Color(0xFFE4EBD9),
    surfaceVariant = Color(0xFF283120),
    onSurfaceVariant = Color(0xFFBBC6B0),
    outline = Color(0xFF394630)
)

// No third-party font files were supplied with the request. This theme uses Android's
// Arabic-capable platform font until licensed, matching font assets can be added.
private val MishkatTypography = Typography(
    displayLarge = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 34.sp, lineHeight = 42.sp),
    headlineLarge = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 27.sp, lineHeight = 36.sp),
    headlineMedium = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 23.sp, lineHeight = 32.sp),
    titleLarge = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 20.sp, lineHeight = 28.sp),
    titleMedium = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 24.sp),
    bodyLarge = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 25.sp),
    bodyMedium = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 22.sp),
    bodySmall = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 18.sp),
    labelLarge = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp),
    labelMedium = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 18.sp)
)

@Composable
fun MishkatTheme(choice: ThemeChoice, content: @Composable () -> Unit) {
    val dark = when (choice) {
        ThemeChoice.LIGHT -> false
        ThemeChoice.DARK -> true
        ThemeChoice.SYSTEM -> androidx.compose.foundation.isSystemInDarkTheme()
    }
    MaterialTheme(
        colorScheme = if (dark) MishkatDarkScheme else MishkatLightScheme,
        typography = MishkatTypography,
        content = content
    )
}
