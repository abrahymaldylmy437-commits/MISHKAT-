package com.mishkat.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.AccessTime
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.CloudDownload
import androidx.compose.material.icons.outlined.CompassCalibration
import androidx.compose.material.icons.outlined.DownloadDone
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.NightsStay
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Spa
import androidx.compose.material.icons.outlined.Sync
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mishkat.app.MishkatViewModel
import com.mishkat.app.data.SourceStatusEntity
import com.mishkat.app.data.ThemeChoice
import com.mishkat.app.ui.components.AppText

@Composable
private fun PageHeader(title: String, onBack: (() -> Unit)? = null) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            Card(onClick = onBack, modifier = Modifier.size(42.dp), shape = CircleShape, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "رجوع") }
            }
        }
        AppText(title, style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun ScreenColumn(title: String, onBack: (() -> Unit)? = null, content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize()) {
        PageHeader(title, onBack)
        content()
    }
}

@Composable
private fun MessageCard(title: String, body: String, icon: androidx.compose.ui.graphics.vector.ImageVector = Icons.Outlined.Info) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.7f))
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                AppText(title, style = MaterialTheme.typography.titleMedium)
                AppText(body, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun QuranIndexScreen(viewModel: MishkatViewModel, onOpenSurah: (Int) -> Unit) {
    val surahs by viewModel.surahs.collectAsState()
    val busy by viewModel.busy.collectAsState()
    val message by viewModel.message.collectAsState()
    var search by rememberSaveable { mutableStateOf("") }
    var juzTab by rememberSaveable { mutableStateOf(false) }
    val filtered = surahs.filter { search.isBlank() || normalizeArabic(it.arabicName).contains(normalizeArabic(search)) || it.id.toString() == search.trim() }
    ScreenColumn("القرآن الكريم") {
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !juzTab, onClick = { juzTab = false }, label = { AppText("السور") })
                FilterChip(selected = juzTab, onClick = { juzTab = true }, label = { AppText("الأجزاء") })
            }
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                label = { AppText("ابحث في أسماء السور") },
                shape = RoundedCornerShape(16.dp)
            )
            if (surahs.isEmpty()) {
                MessageCard("الفهرس غير متوفر محليًا", "لم تُنزّل بيانات السور من المصدر بعد. يحتاج الاتصال بمصدر Quran Foundation إلى بيانات اعتماد صحيحة؛ لن نعرض أسماء أو أعداد آيات مكتوبة يدويًا.", Icons.Outlined.CloudDownload)
                Button(onClick = viewModel::syncQuran, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Icon(Icons.Outlined.Sync, contentDescription = null)
                    Spacer(Modifier.width(8.dp)); AppText("تنزيل بيانات المصحف")
                }
                if (message.isNotBlank()) AppText(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else if (juzTab) {
                MessageCard("فهرس الأجزاء غير مستورد", "تعرض هذه النسخة فهرس السور الذي وصل من المصدر فقط. يلزم استيراد بيانات حدود الأجزاء والأحزاب قبل عرضها.")
            } else {
                AppText("${filtered.size} نتيجة من بيانات المصدر", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 22.dp)) {
                    items(filtered, key = { it.id }) { surah ->
                        Card(
                            onClick = { onOpenSurah(surah.id) },
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.65f))
                        ) {
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Box(Modifier.size(42.dp).background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                                    AppText(surah.id.toString(), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                }
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    AppText(surah.arabicName, style = MaterialTheme.typography.titleMedium)
                                    val place = when (surah.revelationPlace.lowercase()) {
                                        "makkah", "meccan" -> "مكية"
                                        "madinah", "medinan", "medina" -> "مدنية"
                                        else -> surah.revelationPlace.ifBlank { "مكان النزول غير متوفر" }
                                    }
                                    AppText("$place • ${surah.versesCount} آية", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    AppText("صفحة", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    AppText(surah.startPage?.toString() ?: "—", style = MaterialTheme.typography.labelLarge)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QuranReaderScreen(viewModel: MishkatViewModel, surahId: Int?, onBack: () -> Unit) {
    val surahs by viewModel.surahs.collectAsState()
    val verseCount by viewModel.verseCount.collectAsState()
    val surah = surahs.firstOrNull { it.id == surahId }
    ScreenColumn("${surah?.arabicName ?: "قراءة القرآن"}", onBack) {
        Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            MessageCard(
                "عرض الآيات متوقف لحماية دقة النص",
                "لم تُضمّن في الحزمة الحالية خطوط صفحات المصحف الرسمية QCF ومطابقة code_v2 لكل صفحة. لذلك لن يُعرض النص بخط نظام بديل، تجنبًا لتغيير هيئة الرموز أو علامات الوقف. هذا يمنع وضع القراءة حتى إضافة حزمة الخطوط المرخّصة ومخطط الصفحات المطابق للإصدار.",
                Icons.Outlined.MenuBook
            )
            if (surah != null) {
                MessageCard("بيانات الفهرس المستوردة", "السورة: ${surah.arabicName} • عدد الآيات حسب المصدر: ${surah.versesCount} • الصفحة الأولى: ${surah.startPage ?: "غير محددة من المصدر"}")
            }
            AppText("عدد الآيات المخزنة محليًا: $verseCount", color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = { viewModel.syncQuran() }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Outlined.Sync, contentDescription = null); Spacer(Modifier.width(8.dp)); AppText("إعادة مزامنة بيانات المصدر") }
        }
    }
}

@Composable
fun AzkarScreen(viewModel: MishkatViewModel, onOpenChapter: (String) -> Unit) {
    val chapters by viewModel.azkarChapters.collectAsState()
    val itemCount by viewModel.azkarItemCount.collectAsState()
    val chapterCount by viewModel.azkarChapterCount.collectAsState()
    var search by rememberSaveable { mutableStateOf("") }
    var category by rememberSaveable { mutableStateOf("الكل") }
    val categories = listOf("الكل", "قرآن", "حديث", "دعاء", "ذكر")
    val filtered = chapters.filter { chapter ->
        (search.isBlank() || normalizeArabic(chapter.title).contains(normalizeArabic(search))) &&
            (category == "الكل" || category == chapter.category)
    }
    ScreenColumn("الأذكار") {
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AzkarShortcutCard("أذكار الصباح", Icons.Outlined.WbSunny, Modifier.weight(1f)) {
                    val found = chapters.firstOrNull { it.title.contains("الصباح") }
                    if (found != null) onOpenChapter(found.id) else viewModel.postMessage("باب أذكار الصباح غير موجود في البيانات المحلية بعد.")
                }
                AzkarShortcutCard("أذكار المساء", Icons.Outlined.NightsStay, Modifier.weight(1f)) {
                    val found = chapters.firstOrNull { it.title.contains("المساء") }
                    if (found != null) onOpenChapter(found.id) else viewModel.postMessage("باب أذكار المساء غير موجود في البيانات المحلية بعد.")
                }
            }
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth(),
                leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                label = { AppText("ابحث في الأبواب") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp)
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                categories.forEach { option -> FilterChip(selected = category == option, onClick = { category = option }, label = { AppText(option) }) }
            }
            if (chapters.isEmpty()) {
                MessageCard("حصن المسلم غير محمّل", "لم تُرفق بيانات الكتاب في المشروع، ولم يمكن التحقق من استجابة المصدر الحي أثناء إنشاء الحزمة. لذلك لا يوجد محتوى ديني مولّد أو مفترض. تُضاف المزامنة بعد تثبيت استجابة المصدر وترخيص إعادة التوزيع.", Icons.Outlined.CloudDownload)
                AppText("الأبواب المحلية: $chapterCount • الأذكار المحلية: $itemCount", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                AppText("الأبواب: $chapterCount • الأذكار: $itemCount (من قاعدة البيانات)", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                    items(filtered, key = { it.id }) { chapter ->
                        val count by viewModel.observeAzkarCount(chapter.id).collectAsState(initial = 0)
                        Card(
                            onClick = { onOpenChapter(chapter.id) },
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.7f))
                        ) {
                            Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Box(Modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                                    AppText(chapter.sortOrder.toString(), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                }
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    AppText(chapter.title, style = MaterialTheme.typography.titleMedium)
                                    AppText("$count أذكار", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    AppText(count.toString(), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                                    Icon(if (count > 0) Icons.Outlined.DownloadDone else Icons.Outlined.CloudDownload, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(17.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


@Composable
private fun AzkarShortcutCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier.height(106.dp), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Column(Modifier.fillMaxSize().padding(13.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(23.dp))
            AppText(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
        }
    }
}

@Composable
fun AzkarChapterScreen(viewModel: MishkatViewModel, chapterId: String, onBack: () -> Unit) {
    val chapters by viewModel.azkarChapters.collectAsState()
    val itemsFlow = viewModel.observeAzkarItems(chapterId)
    val items by itemsFlow.collectAsState(initial = emptyList())
    val chapter = chapters.firstOrNull { it.id == chapterId }
    val remaining = androidx.compose.runtime.remember { mutableStateMapOf<String, Int>() }
    var currentIndex by rememberSaveable(chapterId) { mutableIntStateOf(0) }
    var previousRemaining by rememberSaveable(chapterId) { mutableIntStateOf(-1) }
    var autoAdvance by rememberSaveable(chapterId) { mutableStateOf(true) }
    var completed by rememberSaveable(chapterId) { mutableStateOf(false) }
    val dayToday = java.time.LocalDate.now().toString()

    LaunchedEffect(items) {
        items.forEach { item -> if (!remaining.containsKey(item.id)) remaining[item.id] = viewModel.azkarRemaining(item) }
    }

    ScreenColumn(chapter?.title ?: "الذكر", onBack) {
        if (items.isEmpty()) {
            Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                MessageCard("لا توجد أذكار مخزنة لهذا الباب", "لن نعرض ذكرًا مصطنعًا. افحص تنزيل الكتاب بعد توفير مصدر موثوق قابل للتحقق.", Icons.Outlined.Spa)
            }
        } else if (completed || currentIndex >= items.size) {
            Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Outlined.CheckCircle, contentDescription = null, modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.primary)
                AppText("تم إتمام الباب", style = MaterialTheme.typography.headlineLarge)
                AppText(chapter?.title ?: "", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Button(onClick = onBack) { AppText("العودة إلى الأبواب") }
            }
        } else {
            val current = items[currentIndex.coerceIn(items.indices)]
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 4.dp, bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                item {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        AppText("الذكر ${currentIndex + 1} من ${items.size}", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AppText("انتقال تلقائي", style = MaterialTheme.typography.bodySmall)
                            Switch(checked = autoAdvance, onCheckedChange = { autoAdvance = it })
                        }
                    }
                }
                item {
                    Card(
                        onClick = {
                            val old = remaining[current.id] ?: current.repeatCount
                            if (old > 0) {
                                previousRemaining = old
                                val new = old - 1
                                remaining[current.id] = new
                                viewModel.saveAzkarRemaining(current, new)
                                if (new == 0 && autoAdvance) {
                                    if (currentIndex + 1 < items.size) currentIndex++ else {
                                        completed = true
                                        viewModel.markAzkarChapterCompleted(chapterId)
                                    }
                                }
                            }
                        },
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                            AppText(current.text, style = MaterialTheme.typography.bodyLarge.copy(fontFamily = FontFamily.Serif, fontSize = 23.sp, lineHeight = 43.sp), textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                            if (!current.virtue.isNullOrBlank()) AppText(current.virtue, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (!current.reference.isNullOrBlank()) AppText("المصدر: ${current.reference}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                AppText("المتبقي", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Box(Modifier.size(64.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape), contentAlignment = Alignment.Center) {
                                    AppText((remaining[current.id] ?: current.repeatCount).toString(), style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                }
                            }
                            AppText("انقر على بطاقة الذكر للعدّ", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            if (previousRemaining >= 0) {
                                remaining[current.id] = previousRemaining
                                viewModel.saveAzkarRemaining(current, previousRemaining)
                                previousRemaining = -1
                            }
                        }, enabled = previousRemaining >= 0, modifier = Modifier.weight(1f)) { AppText("تراجع") }
                        OutlinedButton(onClick = {
                            remaining[current.id] = current.repeatCount
                            viewModel.saveAzkarRemaining(current, current.repeatCount)
                        }, modifier = Modifier.weight(1f)) { AppText("إعادة العدّ") }
                        Button(onClick = {
                            if (currentIndex + 1 < items.size) currentIndex++ else {
                                completed = true
                                viewModel.markAzkarChapterCompleted(chapterId)
                            }
                        }, modifier = Modifier.weight(1f)) { AppText("التالي") }
                    }
                }
                item { AppText("تُحفظ حالة العدّ لهذا اليوم محليًا. اليوم: $dayToday", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
        }
    }
}

@Composable
fun PrayerScreen(viewModel: MishkatViewModel) {
    val message by viewModel.message.collectAsState()
    ScreenColumn("مواقيت الصلاة") {
        Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            MessageCard("لم تُحسب المواقيت بعد", "يلزم تحديد موقع أو مدينة يدويًا، ثم اختيار طريقة الحساب والمذهب. لن تظهر أوقات تقريبية على أنها أوقات صحيحة.", Icons.Outlined.AccessTime)
            Button(onClick = { viewModel.postMessage("ميزة اختيار المدينة وحساب الأوقات لم تُربط في هذه النسخة.") }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Outlined.LocationOn, contentDescription = null); Spacer(Modifier.width(8.dp)); AppText("إعداد الموقع") }
            if (message.isNotBlank()) AppText(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
            MessageCard("التنبيهات", "منبّه الصلاة وتوقيت الأذكار لن يُفعّلا حتى تكتمل حسابات الموقع والصلاحيات وجدولة التنبيه.")
        }
    }
}

@Composable
fun SettingsScreen(viewModel: MishkatViewModel, onBack: () -> Unit, onNavigate: (String) -> Unit) {
    val theme by viewModel.theme.collectAsState()
    ScreenColumn("الإعدادات", onBack) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 18.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { AppText("المظهر", style = MaterialTheme.typography.titleLarge) }
            item {
                Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ThemeChoice.entries.forEach { option ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                AppText(when (option) { ThemeChoice.LIGHT -> "فاتح"; ThemeChoice.DARK -> "داكن"; ThemeChoice.SYSTEM -> "حسب النظام" }, modifier = Modifier.weight(1f))
                                androidx.compose.material3.RadioButton(selected = theme == option, onClick = { viewModel.setTheme(option) })
                            }
                        }
                    }
                }
            }
            item { AppText("المصحف والمحتوى", style = MaterialTheme.typography.titleLarge) }
            item { SettingsAction("حالة المصادر وسجل الأخطاء", "فحص الاتصال بالمصادر", Icons.Outlined.Sync) { onNavigate("sources") } }
            item { SettingsAction("التنزيلات", "المحتوى المحلي والمساحة", Icons.Outlined.CloudDownload) { onNavigate("downloads") } }
            item { SettingsAction("الموقع والمواقيت", "إعداد الموقع وطريقة الحساب", Icons.Outlined.LocationOn) { onNavigate("location") } }
            item { SettingsAction("عن التطبيق والمصادر", "الإصدارات والتراخيص", Icons.Outlined.Info) { onNavigate("about") } }
            item { MessageCard("الخطوط", "ملفات Cairo وNoto Naskh وخط المصحف الرسمي غير مرفقة هنا. يستخدم التطبيق مؤقتًا خط النظام للواجهة فقط ولا يعرض الآيات قبل توفير خط المصحف المطابق.") }
        }
    }
}

@Composable
private fun SettingsAction(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(onClick = onClick, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                AppText(title, style = MaterialTheme.typography.titleMedium)
                AppText(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
fun SourceStatusScreen(viewModel: MishkatViewModel, onBack: () -> Unit) {
    val statuses by viewModel.sourceStatuses.collectAsState()
    val message by viewModel.message.collectAsState()
    val busy by viewModel.busy.collectAsState()
    val sourceInfo = listOf(
        Triple("quran", "المصحف — Quran Foundation API v4", "يحتاج اعتماد API ومطابقة بيانات المصدر"),
        Triple("fonts", "خطوط المصحف", "لم تُرفق حزمة QCF الرسمية"),
        Triple("azkar", "الأذكار — حصن المسلم", "لم يمكن التحقق من الاستجابة الفعلية للمصدر"),
        Triple("audio", "الصوتيات", "لم يتم التحقق من ملفات القرّاء"),
    )
    ScreenColumn("حالة المصادر", onBack) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 18.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(sourceInfo) { info ->
                val status = statuses.firstOrNull { it.sourceId == info.first }
                SourceStatusCard(info.first, info.second, info.third, status)
            }
            item {
                Button(onClick = viewModel::testQuranSource, modifier = Modifier.fillMaxWidth(), enabled = !busy) {
                    if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Icon(Icons.Outlined.Refresh, contentDescription = null)
                    Spacer(Modifier.width(8.dp)); AppText("اختبار اتصال مصدر القرآن")
                }
            }
            item { if (message.isNotBlank()) MessageCard("آخر نتيجة", message) }
        }
    }
}

@Composable
private fun SourceStatusCard(sourceId: String, title: String, notes: String, status: SourceStatusEntity?) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppText(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                Icon(if (status?.isOnline == true) Icons.Outlined.CheckCircle else Icons.Outlined.ErrorOutline, contentDescription = null, tint = if (status?.isOnline == true) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary)
            }
            AppText(if (status == null) "الحالة: لم يُختبر بعد" else if (status.isOnline) "الحالة: متصل" else "الحالة: تعذر الاتصال", style = MaterialTheme.typography.labelLarge)
            AppText(notes, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            status?.lastUpdatedAt?.let { AppText("آخر تحديث محلي: ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(it))}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            status?.lastError?.let { if (it.isNotBlank()) AppText("آخر خطأ: $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
            if (status?.errorLog?.isNotBlank() == true) {
                var showLog by rememberSaveable(sourceId) { mutableStateOf(false) }
                TextButton(onClick = { showLog = !showLog }) { AppText(if (showLog) "إخفاء سجل الأخطاء" else "عرض سجل الأخطاء") }
                AnimatedVisibility(showLog) { AppText(status.errorLog, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
        }
    }
}

@Composable
fun DownloadsScreen(viewModel: MishkatViewModel, onBack: () -> Unit) {
    val surahs by viewModel.surahs.collectAsState()
    val verseCount by viewModel.verseCount.collectAsState()
    val chapters by viewModel.azkarChapters.collectAsState()
    val chapterCount by viewModel.azkarChapterCount.collectAsState()
    val azkarCount by viewModel.azkarItemCount.collectAsState()
    val busy by viewModel.busy.collectAsState()
    val message by viewModel.message.collectAsState()
    ScreenColumn("التنزيلات") {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 18.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                DownloadRow("بيانات القرآن", "${surahs.size} سورة في الفهرس • $verseCount آية مخزنة", surahs.isNotEmpty() && verseCount > 0)
                Spacer(Modifier.height(10.dp))
                Button(onClick = viewModel::syncQuran, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Icon(Icons.Outlined.CloudDownload, contentDescription = null)
                    Spacer(Modifier.width(8.dp)); AppText("تحميل أو استئناف بيانات القرآن")
                }
            }
            item {
                DownloadRow("حصن المسلم", "$chapterCount أبواب • $azkarCount أذكار مخزنة", chapters.isNotEmpty() && azkarCount > 0)
                MessageCard("تنزيل الأذكار", "تم حجب التنزيل في هذه النسخة إلى أن تُثبت استجابة المصدر الفعلية وتراخيص الكتاب والصوت. لا يوجد ملف أذكار وهمي في الحزمة.", Icons.Outlined.CloudDownload)
            }
            item { MessageCard("الصوتيات", "لم تُتحقق ملفات التلاوة ونسبة كل ملف إلى القارئ حتى الآن. لن يُعرض زر تشغيل لصوت غير متحقق.") }
            item { MessageCard("العمل دون إنترنت", "تعمل سجلات Room المتاحة محليًا دون شبكة. تنزيل المحتوى الكامل لم يكتمل في هذه النسخة؛ ستبقى العناصر التي لم تُحمّل غير متاحة.") }
            item { if (message.isNotBlank()) AppText(message, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}

@Composable
private fun DownloadRow(title: String, details: String, downloaded: Boolean) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(if (downloaded) Icons.Outlined.DownloadDone else Icons.Outlined.CloudDownload, contentDescription = null, modifier = Modifier.size(26.dp), tint = MaterialTheme.colorScheme.primary)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                AppText(title, style = MaterialTheme.typography.titleMedium)
                AppText(details, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            AppText(if (downloaded) "محمّل" else "غير مكتمل", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary)
        }
    }
}

@Composable
fun LocationScreen(onBack: () -> Unit) {
    ScreenColumn("الموقع", onBack) {
        Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            MessageCard("إعداد الموقع غير مفعّل بعد", "يلزم دمج Fused Location وواجهة بحث مدينة وحفظ عدة مواقع قبل طلب إذن GPS. لا نطلب صلاحية الموقع حاليًا لأن الشاشة لا تستخدمها بعد.", Icons.Outlined.LocationOn)
            MessageCard("الحساب اليدوي", "لم تُربط بعد مكتبة Adhan بواجهة اختيار طريقة الحساب والمذهب وتعديل الدقائق. لذلك لا تُعرض مواقيت تقديرية.")
        }
    }
}

@Composable
fun QiblaScreen(onBack: () -> Unit) {
    ScreenColumn("القبلة", onBack) {
        Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Outlined.CompassCalibration, contentDescription = null, modifier = Modifier.size(80.dp), tint = MaterialTheme.colorScheme.primary)
            MessageCard("البوصلة غير مفعّلة في هذه النسخة", "يلزم ربط مستشعري المغناطيس والتسارع، حساب اتجاه الكعبة من الإحداثيات، وفلترة القراءات قبل عرض اتجاه. لن نرسم مؤشرًا يوحي باتجاه صحيح دون حساب فعلي.")
        }
    }
}

@Composable
fun TasbeehScreen(onBack: () -> Unit) {
    var count by rememberSaveable { mutableIntStateOf(0) }
    var targetText by rememberSaveable { mutableStateOf("33") }
    val target = targetText.toIntOrNull()?.coerceAtLeast(1)
    ScreenColumn("المسبحة الإلكترونية", onBack) {
        Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
            AppText(count.toString(), style = MaterialTheme.typography.displayLarge)
            AppText(if (target != null && count >= target) "اكتمل الهدف المحدد" else "العدد الحالي", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Card(onClick = { count++ }, modifier = Modifier.size(190.dp), shape = CircleShape, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), border = BorderStroke(2.dp, MaterialTheme.colorScheme.primary)) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Outlined.Spa, contentDescription = null, modifier = Modifier.size(38.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
                        AppText("تسبيح", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
            }
            OutlinedTextField(value = targetText, onValueChange = { targetText = it.filter(Char::isDigit).take(5) }, label = { AppText("الهدف") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            OutlinedButton(onClick = { count = 0 }) { AppText("تصفير العداد") }
            AppText("ملاحظة: حفظ العدد بعد إغلاق الشاشة والاهتزاز غير مفعّلين بعد.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun SearchScreen(viewModel: MishkatViewModel, onBack: () -> Unit, onOpenSurah: (Int) -> Unit) {
    val surahs by viewModel.surahs.collectAsState()
    var query by rememberSaveable { mutableStateOf("") }
    val results = surahs.filter { normalizeArabic(it.arabicName).contains(normalizeArabic(query)) || (query.toIntOrNull() == it.id) }
    ScreenColumn("البحث الشامل", onBack) {
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), label = { AppText("ابحث في السور المتوفرة محليًا") }, leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) }, singleLine = true)
            if (surahs.isEmpty()) MessageCard("لا توجد بيانات بحث محلية", "نزّل فهرس السور أولًا. البحث في الآيات والأذكار غير مفعّل حتى تكتمل مزامنة مصادرها.")
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(results, key = { it.id }) { surah ->
                    Card(onClick = { onOpenSurah(surah.id) }, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            AppText(surah.id.toString(), color = MaterialTheme.colorScheme.primary, modifier = Modifier.width(40.dp))
                            AppText(surah.arabicName, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                            AppText(surah.versesCount.toString(), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AboutScreen(onBack: () -> Unit) {
    ScreenColumn("عن مِشكاة", onBack) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Card(shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF08484A))) {
                    Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Image(
                            painter = painterResource(id = com.mishkat.app.R.drawable.mishkat_lockup),
                            contentDescription = "شعار مِشكاة — MISHKAT",
                            modifier = Modifier.fillMaxWidth().height(110.dp)
                        )
                        AppText("نورٌ لقلبك.. في كل حين", color = Color(0xFFF2E6DC))
                    }
                }
            }
            item { MessageCard("الإصدار", "0.1.0-alpha — نموذج أولي قابل للبناء. المزايا غير المكتملة موضحة في ملف TESTING.md.") }
            item { MessageCard("المصادر", "خطة التكامل: Quran Foundation Content API v4. نص Tanzil لا يُضمّن في هذه الحزمة؛ عند إضافته يجب حفظ نص الإسناد والترخيص دون تغيير النص، مع رابط tanzil.net.") }
            item { MessageCard("التراخيص", "لا تُضمّن هذه الحزمة ملفات خطوط خارجية أو بيانات قرآنية/أذكار منسوخة. يجب مراجعة شروط API والخطوط والصوتيات قبل شحن إصدار إنتاجي.") }
        }
    }
}

private fun normalizeArabic(input: String): String = input
    .lowercase()
    .replace(Regex("[\\u064B-\\u065F\\u0670\\u0640]"), "")
    .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
    .replace('ى', 'ي').replace('ة', 'ه')

@Composable
fun FavoritesScreen(onBack: () -> Unit) {
    ScreenColumn("المفضلة", onBack) {
        Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            MessageCard("لا توجد مفضلات محفوظة في هذه النسخة", "لم يتم بعد ربط حفظ الآيات والأذكار بجدول المفضلة، لذلك لا نعرض عناصر تجريبية أو محتوى مفترض.", Icons.Outlined.FavoriteBorder)
        }
    }
}
