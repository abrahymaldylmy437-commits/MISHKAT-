package com.mishkat.app.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.mishkat.app.BuildConfig
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MishkatRepository @Inject constructor(
    private val dao: MishkatDao,
    private val api: QuranApi,
    @ApplicationContext private val context: Context
) {
    fun observeSurahs(): Flow<List<SurahEntity>> = dao.observeSurahs()
    fun observeVerseCount(): Flow<Int> = dao.observeVerseCount()
    fun observeLastReadPage(): Flow<ReadPageEntity?> = dao.observeLastReadPage()
    fun observeReadPageCount(): Flow<Int> = dao.observeReadPageCount()
    fun observeAzkarChapters(): Flow<List<AzkarChapterEntity>> = dao.observeAzkarChapters()
    fun observeSources(): Flow<List<SourceStatusEntity>> = dao.observeSourceStatuses()
    fun observeAzkarItemCount(): Flow<Int> = dao.observeAzkarItemCount()
    fun observeAzkarChapterCount(): Flow<Int> = dao.observeAzkarChapterCount()
    fun observeAzkarItems(chapterId: String) = dao.observeAzkarItems(chapterId)
    fun observeAzkarCount(chapterId: String) = dao.observeAzkarCountByChapter(chapterId)

    suspend fun azkarRemaining(item: AzkarItemEntity, dayKey: String): Int =
        dao.getAzkarProgress(item.id, dayKey)?.remaining ?: item.repeatCount

    suspend fun saveAzkarRemaining(item: AzkarItemEntity, dayKey: String, remaining: Int) {
        dao.putAzkarProgress(AzkarProgressEntity(item.id, item.chapterId, dayKey, remaining.coerceAtLeast(0), System.currentTimeMillis()))
    }

    suspend fun markAzkarChapterCompleted(chapterId: String, dayKey: String) {
        val key = "$chapterId:$dayKey"
        dao.putCompletion(AzkarCompletionEntity(key, chapterId, dayKey, System.currentTimeMillis()))
    }

    suspend fun getVersesForPage(pageNumber: Int) = dao.getVersesForPage(pageNumber)
    suspend fun markPageRead(pageNumber: Int) {
        val now = System.currentTimeMillis()
        val existing = dao.getVersesForPage(pageNumber) // also ensures an uncached page isn't counted as read
        if (existing.isNotEmpty()) dao.markPageRead(ReadPageEntity(pageNumber, now, now))
    }

    suspend fun syncQuranIndexAndText(progress: (String) -> Unit = {}): Result<Unit> = runCatching {
        if (BuildConfig.QURAN_CLIENT_ID.isBlank() || BuildConfig.QURAN_AUTH_TOKEN.isBlank()) {
            val message = "بيانات اعتماد Quran Foundation غير مهيأة. أضف QURAN_CLIENT_ID وQURAN_AUTH_TOKEN في gradle.properties أو إعدادات البناء."
            recordSource("quran", false, message)
            error(message)
        }
        progress("الاتصال بمصدر القرآن")
        val chapters = requireNotNull(api.chapters().chapters) { "لم يُرجع المصدر قائمة السور" }
        require(chapters.size == 114) { "عدد السور المستلم ${chapters.size}؛ المتوقع 114 بحسب المصدر." }
        val now = System.currentTimeMillis()
        dao.putSurahs(chapters.map { chapter ->
            SurahEntity(
                id = chapter.id,
                arabicName = chapter.nameArabic.orEmpty(),
                revelationPlace = chapter.revelationPlace.orEmpty(),
                versesCount = chapter.versesCount,
                startPage = chapter.pages?.firstOrNull(),
                sourceUpdatedAt = now
            )
        })
        chapters.forEachIndexed { index, chapter ->
            progress("استيراد بيانات السورة ${index + 1} من ${chapters.size}")
            var page = 1
            var totalPages = 1
            do {
                val response = api.versesByChapter(chapter.id, page = page)
                val verses = response.verses.orEmpty()
                dao.putVerses(verses.mapNotNull { verse ->
                    val keyParts = verse.verseKey.split(":")
                    val verseNumber = verse.verseNumber ?: keyParts.getOrNull(1)?.toIntOrNull()
                    val text = verse.textUthmani
                    val pageNumber = verse.pageNumber
                    if (verseNumber == null || text.isNullOrBlank() || pageNumber == null) null else VerseEntity(
                        verseKey = verse.verseKey,
                        chapterId = chapter.id,
                        verseNumber = verseNumber,
                        uthmaniText = text,
                        pageNumber = pageNumber,
                        juzNumber = verse.juzNumber ?: 0,
                        source = "Quran Foundation Content API v4",
                        sourceUpdatedAt = now
                    )
                })
                totalPages = response.pagination?.totalPages ?: if (verses.size >= 300) page + 1 else page
                page++
            } while (page <= totalPages)
        }
        val localChapters = dao.getSurahs()
        val localVerses = dao.getAllVerses()
        require(localChapters.size == 114) { "فشل تحقق عدد السور في قاعدة البيانات." }
        require(localVerses.size == 6236) { "تحقق الآيات غير مطابق للمجموع الرسمي المتوقع؛ المخزن ${localVerses.size}. لم تُعلن المزامنة مكتملة." }
        recordSource("quran", true, null)
    }.onFailure { failure -> recordSource("quran", false, failure.message ?: failure.javaClass.simpleName) }

    suspend fun testQuranSource(): Result<String> = runCatching {
        if (!isOnline()) error("لا يوجد اتصال بالشبكة حالياً")
        if (BuildConfig.QURAN_CLIENT_ID.isBlank() || BuildConfig.QURAN_AUTH_TOKEN.isBlank()) {
            error("بيانات اعتماد Quran Foundation غير مهيأة")
        }
        val result = api.chapters()
        val count = result.chapters?.size ?: 0
        require(count > 0) { "المصدر لم يُرجع قائمة السور" }
        recordSource("quran", true, null)
        "نجح الاتصال؛ عدد السور الواردة من المصدر: $count"
    }.onFailure { recordSource("quran", false, it.message ?: "خطأ غير معروف") }

    suspend fun recordSource(sourceId: String, online: Boolean, error: String?) {
        val existing = dao.getSourceStatus(sourceId)
        val logLine = "${java.time.Instant.now()} | ${if (online) "OK" else "ERROR"} | ${error.orEmpty()}"
        val combined = listOfNotNull(existing?.errorLog?.takeIf { it.isNotBlank() }, logLine).joinToString("\n").takeLast(8000)
        dao.putSourceStatus(
            SourceStatusEntity(
                sourceId = sourceId,
                isOnline = online,
                lastUpdatedAt = if (online) System.currentTimeMillis() else existing?.lastUpdatedAt,
                lastError = error,
                errorLog = combined
            )
        )
    }

    fun isOnline(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}
