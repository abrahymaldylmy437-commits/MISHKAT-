package com.mishkat.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccessTime
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.Spa
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.graphicsLayer
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.mishkat.app.MishkatViewModel
import com.mishkat.app.ui.components.AppText
import com.mishkat.app.ui.screens.AboutScreen
import com.mishkat.app.ui.screens.AzkarChapterScreen
import com.mishkat.app.ui.screens.AzkarScreen
import com.mishkat.app.ui.screens.HomeScreen
import com.mishkat.app.ui.screens.LocationScreen
import com.mishkat.app.ui.screens.PrayerScreen
import com.mishkat.app.ui.screens.QiblaScreen
import com.mishkat.app.ui.screens.QuranIndexScreen
import com.mishkat.app.ui.screens.QuranReaderScreen
import com.mishkat.app.ui.screens.SearchScreen
import com.mishkat.app.ui.screens.SettingsScreen
import com.mishkat.app.ui.screens.SourceStatusScreen
import com.mishkat.app.ui.screens.TasbeehScreen
import com.mishkat.app.ui.screens.DownloadsScreen
import com.mishkat.app.ui.screens.FavoritesScreen

private enum class MainTab(val label: String, val icon: ImageVector) {
    HOME("الرئيسية", Icons.Outlined.Home),
    AZKAR("الأذكار", Icons.Outlined.Spa),
    QURAN("القرآن", Icons.Outlined.MenuBook),
    PRAYERS("المواقيت", Icons.Outlined.AccessTime),
    MORE("المزيد", Icons.Outlined.MoreHoriz)
}

@Composable
fun MishkatRoot(viewModel: MishkatViewModel, modifier: Modifier = Modifier) {
    var selectedTabName by rememberSaveable { mutableStateOf(MainTab.HOME.name) }
    var route by rememberSaveable { mutableStateOf("") }
    val selectedTab = MainTab.valueOf(selectedTabName)
    BackHandler(enabled = route.isNotEmpty()) { route = "" }

    Box(modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(bottom = if (route.isEmpty()) 100.dp else 0.dp),
            verticalArrangement = Arrangement.Top
        ) {
            if (route.isEmpty()) {
                when (selectedTab) {
                    MainTab.HOME -> HomeScreen(viewModel, onNavigate = { destination ->
                        when (destination) {
                            "quran" -> { selectedTabName = MainTab.QURAN.name; route = "" }
                            "azkar" -> { selectedTabName = MainTab.AZKAR.name; route = "" }
                            "prayers" -> { selectedTabName = MainTab.PRAYERS.name; route = "" }
                            "more" -> { selectedTabName = MainTab.MORE.name; route = "" }
                            else -> route = destination
                        }
                    })
                    MainTab.AZKAR -> AzkarScreen(viewModel, onOpenChapter = { id -> route = "azkarChapter:$id" })
                    MainTab.QURAN -> QuranIndexScreen(viewModel, onOpenSurah = { surahId -> route = "reader:$surahId" })
                    MainTab.PRAYERS -> PrayerScreen(viewModel)
                    MainTab.MORE -> MoreScreen(
                        onNavigate = { destination -> route = destination },
                        onSelectTab = { tab -> selectedTabName = tab.name; route = "" }
                    )
                }
            } else {
                when {
                    route == "settings" -> SettingsScreen(viewModel, onBack = { route = "" }, onNavigate = { route = it })
                    route == "sources" -> SourceStatusScreen(viewModel, onBack = { route = "" })
                    route == "downloads" -> DownloadsScreen(viewModel, onBack = { route = "" })
                    route == "about" -> AboutScreen(onBack = { route = "" })
                    route == "favorites" -> FavoritesScreen(onBack = { route = "" })
                    route == "location" -> LocationScreen(onBack = { route = "" })
                    route == "qibla" -> QiblaScreen(onBack = { route = "" })
                    route == "tasbeeh" -> TasbeehScreen(onBack = { route = "" })
                    route == "search" -> SearchScreen(viewModel, onBack = { route = "" }, onOpenSurah = { route = "reader:$it" })
                    route == "azkar" -> AzkarScreen(viewModel, onOpenChapter = { route = "azkarChapter:$it" })
                    route.startsWith("azkarChapter:") -> AzkarChapterScreen(
                        viewModel,
                        chapterId = route.substringAfter(":"),
                        onBack = { route = "" }
                    )
                    route.startsWith("reader:") -> QuranReaderScreen(
                        viewModel,
                        surahId = route.substringAfter(":").toIntOrNull(),
                        onBack = { route = "" }
                    )
                    else -> AboutScreen(onBack = { route = "" })
                }
            }
        }

        if (route.isEmpty()) {
            FloatingNavBar(
                selected = selectedTab,
                onSelect = { selectedTabName = it.name },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 16.dp)
                    .padding(bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 12.dp)
            )
        }
    }
}

@Composable
private fun FloatingNavBar(selected: MainTab, onSelect: (MainTab) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .shadow(12.dp, CircleShape, clip = false)
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.94f), CircleShape)
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.62f), CircleShape)
            .padding(horizontal = 6.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        MainTab.entries.forEach { tab ->
            val isSelected = tab == selected
            val width by animateDpAsState(
                targetValue = if (isSelected) 112.dp else 48.dp,
                animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                label = "nav-pill-width"
            )
            val source = remember(tab) { MutableInteractionSource() }
            val pressed by source.collectIsPressedAsState()
            Row(
                modifier = Modifier
                    .width(width)
                    .size(height = 48.dp, width = width)
                    .graphicsLayer(scaleX = if (pressed) 0.96f else 1f, scaleY = if (pressed) 0.96f else 1f)
                    .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent, CircleShape)
                    .then(Modifier)
                    .padding(horizontal = if (isSelected) 10.dp else 0.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = if (isSelected) Arrangement.spacedBy(7.dp) else Arrangement.Center
            ) {
                androidx.compose.foundation.layout.Box(
                    modifier = Modifier
                        .size(38.dp)
                        .background(Color.Transparent, CircleShape)
                        .clickable(interactionSource = source, indication = null, onClick = { onSelect(tab) }),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(tab.icon, contentDescription = tab.label, tint = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (isSelected) {
                    AppText(
                        text = tab.label,
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        maxLines = 1,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun MoreScreen(onNavigate: (String) -> Unit, onSelectTab: (MainTab) -> Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        AppText("المزيد", style = MaterialTheme.typography.headlineLarge)
        AppText("أدوات مشكاة وإعداداتها", color = MaterialTheme.colorScheme.onSurfaceVariant)
        val options = listOf(
            Triple("التنزيلات", "المحتوى الذي أصبح متاحًا دون اتصال", "downloads"),
            Triple("حالة المصادر", "الاتصال والمزامنة وسجل الأخطاء", "sources"),
            Triple("الإعدادات", "المظهر والمحتوى والتنبيهات", "settings"),
            Triple("القبلة", "أداة اتجاه القبلة", "qibla"),
            Triple("المسبحة", "عداد تسبيح بسيط", "tasbeeh"),
            Triple("عن مشكاة", "المصادر والتراخيص وإصدار التطبيق", "about")
        )
        options.forEach { (title, subtitle, destination) ->
            Card(
                onClick = { onNavigate(destination) },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.65f)),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(22.dp)
            ) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    AppText(title, style = MaterialTheme.typography.titleMedium)
                    AppText(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
